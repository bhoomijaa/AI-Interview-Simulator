import asyncio
import edge_tts
import pygame
import tempfile
import os
import subprocess


async def speak_edge_tts(text, voice="en-US-AriaNeural", rate="+0%", pitch="+0Hz"):
    """
    High-quality TTS using Microsoft Edge voices

    Popular voices:
    - en-US-AriaNeural (female)
    - en-US-GuyNeural (male)
    - en-GB-SoniaNeural (British female)
    - en-AU-NatashaNeural (Australian female)
    """
    try:
        communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)

        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp_file:
            await communicate.save(tmp_file.name)

            # Play using pygame
            pygame.mixer.init()
            pygame.mixer.music.load(tmp_file.name)
            pygame.mixer.music.play()

            while pygame.mixer.music.get_busy():
                pygame.time.wait(100)

            pygame.mixer.quit()

        os.unlink(tmp_file.name)

    except Exception as e:
        print(f"Edge-TTS Error: {e}, falling back to macOS say")
        _speak_macos(text)


def _speak_macos(text):
    """Fallback TTS using macOS built-in say command"""
    try:
        subprocess.run(["say", text], check=True)
    except Exception as e:
        print(f"macOS say Error: {e}")


def speak_text(text, voice="en-US-GuyNeural", rate="+0%", pitch="+0Hz"):
    """Synchronous wrapper for Edge-TTS"""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import nest_asyncio
            nest_asyncio.apply()
            loop.run_until_complete(speak_edge_tts(text, voice, rate, pitch))
        else:
            asyncio.run(speak_edge_tts(text, voice, rate, pitch))
    except Exception as e:
        print(f"TTS Error: {e}, falling back to macOS say")
        _speak_macos(text)
